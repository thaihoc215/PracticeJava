-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 22, 2015 at 06:34 PM
-- Server version: 5.1.49-community
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `t3h_ecommerce`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE IF NOT EXISTS `account` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `full_name` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `username`, `password`, `full_name`) VALUES
(2, 'admin', 'admin', 'Nguyen Van A');

-- --------------------------------------------------------

--
-- Table structure for table `ecom_product`
--

CREATE TABLE IF NOT EXISTS `ecom_product` (
  `product_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_name` varchar(45) COLLATE utf8_bin NOT NULL COMMENT 'ten product',
  `product_price` double NOT NULL COMMENT 'gia product',
  `product_price_promotion` double NOT NULL COMMENT 'gia khuyen mai',
  `description` varchar(1000) COLLATE utf8_bin NOT NULL COMMENT 'mo ta san pham',
  `product_category_id` int(10) unsigned NOT NULL COMMENT 'tham chieu toi category product',
  `product_image` varchar(500) COLLATE utf8_bin DEFAULT NULL COMMENT 'link hinh anh cua product',
  `maker_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `maker` varchar(45) COLLATE utf8_bin NOT NULL COMMENT 'user tao',
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bang mo ta product' AUTO_INCREMENT=21 ;

--
-- Dumping data for table `ecom_product`
--

INSERT INTO `ecom_product` (`product_id`, `product_name`, `product_price`, `product_price_promotion`, `description`, `product_category_id`, `product_image`, `maker_date`, `maker`) VALUES
(1, 'Tủ lạnh', 10000, 20000, 'Tủ lạnh Panasonic ', 1, 'http://localhost:8080/eElectroniceWeb/img/product-2.jpg', '2015-09-12 11:31:12', ''),
(2, 'Máy giặt Panasoic 1140', 200000, 3000000, 'Máy giặt ...', 1, 'https://lh4.googleusercontent.com/9czghnB8f49EyjC6yf7MBV83FbgcOVki_OiabTgBd4XcdZZUW8pcjDeJO8qcfp5YVa1OlA=w1325-h501', '2015-09-12 11:31:12', ''),
(16, 'Sạc trên ô tô Pisen Dual USB I Car Charger', 1100, 2005,Pisen Dual USB I Car Charger,1,'http://p.vatgia.vn/ir/pictures_fullsize/8/c3RvMTM4MzIwODUzNy5qcGc-/sac-tren-o-to-pisen-dual-usb-i-car-charger.jpg', '2015-09-22 15:30:03', 'unknow'),
(20, 'Iphone 6', 200005, 500000,IPhone 6 mo ta, 1, 'https://lh5.googleusercontent.com/n8OtwRAO2FzI_OcPBn5-eawuHDrduuPaQ-gd7QZi00o3R9_2fTKNjJKv3K7u3wIQ4fNw2A=s190', '2015-09-22 15:44:46', 'unknow');

-- --------------------------------------------------------

--
-- Table structure for table `ecom_product_category`
--

CREATE TABLE IF NOT EXISTS `ecom_product_category` (
  `product_category_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_name` varchar(45) COLLATE utf8_bin NOT NULL,
  `description` varchar(500) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`product_category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='table dinh nghia catalog cua product' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `ecom_product_category`
--

INSERT INTO `ecom_product_category` (`product_category_id`, `category_name`, `description`) VALUES
(1, 'Điện máy', 'các sản phẩm điện máy'),
(2, 'Điện lạnh', 'Sản phẩm điện lạnh như máy lạnh');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
