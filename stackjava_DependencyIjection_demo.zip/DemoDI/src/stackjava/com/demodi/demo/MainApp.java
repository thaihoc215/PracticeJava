package stackjava.com.demodi.demo;

public class MainApp {
	public static void main(String[] args) {
		Client client = new Client();
		client.execute();
	}
}
