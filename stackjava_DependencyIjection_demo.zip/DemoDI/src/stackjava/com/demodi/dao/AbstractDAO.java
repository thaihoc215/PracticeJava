package stackjava.com.demodi.dao;

public interface AbstractDAO {
	void insert();

	void delete();

	void update();

}
