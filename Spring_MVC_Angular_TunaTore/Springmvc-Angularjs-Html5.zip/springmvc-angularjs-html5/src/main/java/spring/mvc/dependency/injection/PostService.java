package spring.mvc.dependency.injection;

public interface PostService {
	public boolean publishPost(String content);

}
