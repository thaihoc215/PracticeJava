package stackjava.com.springhibernate.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import stackjava.com.springhibernate.entities.Customer;

@Repository(value = "customerDAO")
@Transactional(rollbackFor = Exception.class)
public class CustomerDAO {
	
	@Autowired
	private SessionFactory sessionFactory;


	public void test(Customer customer) throws Exception {
		this.save(customer);
		this.demoException();
	}
	
	public void save(Customer customer) {
		Session session = this.sessionFactory.getCurrentSession();
		session.save(customer);
		System.out.println("save done!");
	}
	
	public void demoException() throws Exception {
		// do something
		throw new Exception("demo throw exception");
	}

}
