package stackjava.com.springhibernate.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import stackjava.com.springhibernate.dao.CustomerDAO;
import stackjava.com.springhibernate.entities.Customer;

public class MainApp {
	public static void main(String[] args) throws Exception {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		CustomerDAO customerDAO = (CustomerDAO) context.getBean("customerDAO");
		
		Customer customer = new Customer("Rooney", "Manchester");
		customerDAO.test(customer);
		context.close();
	}
}
