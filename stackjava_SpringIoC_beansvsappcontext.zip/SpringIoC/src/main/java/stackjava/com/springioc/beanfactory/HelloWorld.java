package stackjava.com.springioc.beanfactory;

public class HelloWorld {
	private String message;

	public void setMessage(String message) {
		this.message = message;
	}

	public void getMessage() {
		System.out.println("Print : " + message);
	}
}